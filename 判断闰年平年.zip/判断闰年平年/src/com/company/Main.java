package com.company;
import java.util.Scanner;
import java.util.Calendar;
import java.util.Date;
public class Main {

    public static void main(String[] args) {
        int year;
        int month;
        Scanner sc = new Scanner(System.in);
        System.out.print("请输入年份：");
        year = sc.nextInt();
        if(year%4==0&&year%100==0&&year%400==0){
            System.out.print("闰年");
        }else{
            System.out.print("平年");
        }

    }
}
